<?php
    echo 'Ini dashboard';  
?>