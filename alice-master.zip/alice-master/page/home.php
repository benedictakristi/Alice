<?php
    echo 'Ini Home';
?>