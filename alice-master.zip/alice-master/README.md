# Final Proyek ALICE

# Penting ! Tolong Sync dulu sebelum mulai bekerja

# Getting Started
1. Buat folder di drive pc mu
2. Buka VS Code, open folder yang dibuat tadi.
3. Pilih menu Terminal > New Terminal. Konfigurasi akun git :
```
#git config --global user.email "email@example.com"
#git config --global user.name "Your Name"
```

4. Clone git dari gitlab
``#git clone https://gitlab.com/pwlanjut/alice.git``
5. Done

# Commit your work
1. Save kerjaanmu.
2. Di VS Code pilih bagian Source Control (Ctrl+Shift+G)
3. Detail perubahan/kerjaanmu terlihat di sidebar kiri. Pilih tanda + (Stage all Change).
4. Masukkan message yang isinya kamu tadi ngerjain apa.
5. Klik Commit (Tanda V / centang diatas)
6. Klik tanda titik 3 diatas, pilih Sync
7. Done
